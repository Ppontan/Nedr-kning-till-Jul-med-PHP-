 <!DOCTYPE html>
<html>
<head>
<title>Nedräkning</title>
<style>
body {background-color: #FFF8DC;}
</style>
</head>
<body>

<center>
<h1>Nedräkning till julafton!</h1>
<p>När är det jul?</p>
</center>


<center>
<?php
// Return current date from the remote server
$date = date('d-m-y h:i:s');
echo $date;
?>
</center>

<center>
<?php

    $datum = mktime(0, 0, 0, 12, 24, 2023) ;//Vilken dag nedräkningen är för

    $today = time () ;

    $difference =($datum-$today) ;

    $månad =date('m',$difference) ;
    $dagar =date('d',$difference) ;
    $timmar =date('h',$difference) ;

    print $månad." månader".$dagar." dagar".$timmar."timmar kvar";

    ?>


</center>
 


</body>
</html> 